import { useEffect, useMemo, useRef, useState, createContext, useContext, type ReactNode, type FormEvent, type ChangeEvent } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { arSA } from '@clerk/localizations';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';
import {
  ArrowLeft, Check, CircleUserRound, ClipboardList, Heart, Menu, Minus, Package,
  Plus, Search, ShieldCheck, ShoppingBag, Truck, X,
} from 'lucide-react';
import {
  getGetAdminInventoryQueryKey,
  getGetAdminSummaryQueryKey,
  getGetProductQueryKey,
  getListAdminOrdersQueryKey, getListAdminProductsQueryKey, getListProductsQueryKey, getTrackOrderQueryKey,
  getUpdateAdminOrderMutationKey, getUpdateAdminProductMutationKey, useCreateAdminProduct,
  useCreateOrder, useDeleteAllAdminOrders, useDeleteAdminProduct, useGetAdminInventory, useGetAdminSummary, useGetProduct, useListAdminOrders, useListAdminProducts,
  useListProducts, useTrackOrder, useUpdateAdminOrder, useUpdateAdminProduct,
  type AdminOrder, type AdminProduct, type OrderInput, type OrderUpdate, type Product, type ProductInput,
} from '@workspace/api-client-react';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

const appearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: {
    colorPrimary: '#234d40', colorForeground: '#263b33', colorMutedForeground: '#718078',
    colorDanger: '#a7443e', colorBackground: '#fbf9f4', colorInput: '#fffefa',
    colorInputForeground: '#263b33', colorNeutral: '#ddd7ca', fontFamily: 'IBM Plex Sans Arabic',
    borderRadius: '0.65rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center', cardBox: 'bg-[#fbf9f4] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none', footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#263b33]', headerSubtitle: 'text-[#718078]', socialButtonsBlockButtonText: 'text-[#263b33]',
    formFieldLabel: 'text-[#263b33]', footerActionLink: 'text-[#234d40]', footerActionText: 'text-[#718078]',
    dividerText: 'text-[#718078]', identityPreviewEditButton: 'text-[#234d40]', formFieldSuccessText: 'text-[#234d40]',
    alertText: 'text-[#263b33]', logoBox: 'rounded-xl', logoImage: 'max-h-12', socialButtonsBlockButton: 'border-[#ddd7ca]',
    formButtonPrimary: 'bg-[#234d40] hover:bg-[#193c31]', formFieldInput: 'border-[#ddd7ca] bg-[#fffefa] text-[#263b33]',
    footerAction: 'text-[#718078]', dividerLine: 'bg-[#ddd7ca]', alert: 'bg-[#f2ede2]',
    otpCodeFieldInput: 'border-[#ddd7ca]', formFieldRow: 'text-[#263b33]', main: 'text-[#263b33]',
  },
};

type CartEntry = { product: Product; quantity: number; color: string; size: string };
type CartApi = { items: CartEntry[]; add: (product: Product, quantity: number, color: string, size: string) => void; remove: (id: string) => void; update: (id: string, quantity: number) => void; clear: () => void };
const CartContext = createContext<CartApi | null>(null);
function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('Cart provider is missing');
  return value;
}
function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartEntry[]>(() => {
    try { return JSON.parse(localStorage.getItem('zstore-cart') || '[]') as CartEntry[]; } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('zstore-cart', JSON.stringify(items)); }, [items]);
  const value = useMemo<CartApi>(() => ({
    items,
    add: (product, quantity, color, size) => setItems((prev) => {
      const found = prev.find((line) => line.product.id === product.id && line.color === color && line.size === size);
      return found ? prev.map((line) => line === found ? { ...line, quantity: line.quantity + quantity } : line) : [...prev, { product, quantity, color, size }];
    }),
    remove: (id) => setItems((prev) => prev.filter((line) => `${line.product.id}:${line.color}:${line.size}` !== id)),
    update: (id, quantity) => setItems((prev) => prev.map((line) => `${line.product.id}:${line.color}:${line.size}` === id ? { ...line, quantity: Math.max(1, quantity) } : line)),
    clear: () => setItems([]),
  }), [items]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

const variantKey = (color: string, size: string) => `${color}\u0001${size}`;
const parseList = (text: string) => [...new Set(text.split(/[،,]/).map((value) => value.trim()).filter(Boolean))];

/** Shrinks a phone/laptop photo so it can be stored with the product. */
function imageFileToDataUrl(file: File, maxSide = 1000): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(image.naturalWidth * scale);
      canvas.height = Math.round(image.naturalHeight * scale);
      const context = canvas.getContext('2d');
      if (!context) { URL.revokeObjectURL(url); reject(new Error('canvas')); return; }
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.85));
    };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('image')); };
    image.src = url;
  });
}

const money = (value: number) => `${Number(value || 0).toLocaleString('ar-EG')} ج.م`;
const statusName = (status: string) => ({ received: 'تم استلام الطلب', preparing: 'قيد التجهيز', out_for_delivery: 'خرج للتوصيل', delivered: 'تم التوصيل', cancelled: 'ملغي' }[status] || status);

function BrandMark() {
  return <span className="brand-mark" aria-hidden="true">
    <svg viewBox="0 0 40 40" fill="none">
      <path d="M11.5 12.5h17L11.5 27.5h17" stroke="currentColor" strokeWidth="3.2" strokeLinecap="square" strokeLinejoin="round" />
    </svg>
  </span>;
}

function Header() {
  const { items } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  return <header className="site-header">
    <div className="announcement"><Truck size={15} /> توصيل ثابت لكل المحافظات بـ ٨٠ جنيه</div>
    <div className="nav-wrap">
      <button className="icon-button mobile-menu" aria-label="القائمة" data-testid="button-menu" onClick={() => setMenuOpen(!menuOpen)}><Menu /></button>
      <Link href="/" className="brand" data-testid="link-home"><BrandMark /><span><b>ZSTORE</b><small>STYLE, SELECTED</small></span></Link>
      <nav className={`main-nav ${menuOpen ? 'menu-open' : ''}`}>
        <Link href="/" data-testid="link-store">الرئيسية</Link>
        <Link href="/#products" data-testid="link-products">تسوقي الآن</Link>
        <Link href="/track" data-testid="link-track">تتبّع طلبك</Link>
      </nav>
      <div className="nav-actions">
        <Link href="/cart" className="cart-link" aria-label="سلة التسوق" data-testid="link-cart"><ShoppingBag size={19} /><span>السلة</span><b data-testid="text-cart-count">{count}</b></Link>
      </div>
    </div>
  </header>;
}
function Footer() {
  return <footer className="footer"><div className="footer-inner">
    <div className="footer-brand"><BrandMark /><div><b>ZSTORE</b><small>STYLE, SELECTED</small></div></div>
    <p className="footer-note">توصيل موثوق لكل أنحاء مصر <span>•</span> رسوم توصيل ثابتة ٨٠ ج.م</p>
    <Link href="/track" data-testid="link-footer-track">تابعي طلبك <ArrowLeft size={15} /></Link>
  </div><div className="copyright">© ZSTORE — التسوق ببساطة وراحة بال</div></footer>;
}
function Shell({ children }: { children: ReactNode }) {
  return <div dir="rtl" className="app-shell"><Header />{children}<Footer /></div>;
}
function ProductImage({ product, className = '' }: { product: Product; className?: string }) {
  const [failed, setFailed] = useState(false);
  return product.image && !failed
    ? <img className={`product-image ${className}`} src={product.image} alt={product.name} onError={() => setFailed(true)} data-testid={`img-product-${product.id}`} />
    : <div className={`product-placeholder ${className}`} data-testid={`img-product-${product.id}`}><span>ZSTORE</span><i>اختيار مميز</i></div>;
}
function ProductCard({ product }: { product: Product }) {
  return <article className="product-card" data-testid={`card-product-${product.id}`}>
    <Link href={`/product/${product.id}`} className="product-art" data-testid={`link-product-${product.id}`}><ProductImage product={product} /><span className="product-ribbon">اختيار الموسم</span></Link>
    <div className="product-info">
      <Link href={`/product/${product.id}`} className="product-name" data-testid={`text-product-name-${product.id}`}>{product.name}</Link>
      <div className="product-card-bottom"><strong data-testid={`text-product-price-${product.id}`}>{money(product.priceSingle)}</strong><span>{product.stock > 0 ? 'متوفر' : 'نفد المخزون'}</span></div>
    </div>
  </article>;
}
function LoadingGrid() {
  return <div className="product-grid" aria-label="جارٍ تحميل المنتجات">{[1, 2, 3, 4].map((item) => <div key={item} className="skeleton-card"><div className="skeleton-block" /><div className="skeleton-line" /><div className="skeleton-line short" /></div>)}</div>;
}
function Storefront() {
  const productsQuery = useListProducts();
  const [search, setSearch] = useState('');
  const products = productsQuery.data || [];
  const filtered = products.filter((product) => product.name.toLocaleLowerCase('ar').includes(search.toLocaleLowerCase('ar')) || product.description.toLocaleLowerCase('ar').includes(search.toLocaleLowerCase('ar')));
  return <Shell>
    <main>
      <section className="hero">
        <div className="hero-content"><span className="eyebrow">من القاهرة، لكل حكاية</span><h1>تفاصيل صغيرة،<br /><em>فرق كبير.</em></h1>
          <p>قطع مختارة بعناية لتكون جزءًا من يومك — خامات مريحة، ألوان تدوم، وأسعار واضحة من أول لحظة.</p>
          <a href="#products" className="button button-primary" data-testid="link-shop-now">اكتشفي التشكيلة <ArrowLeft size={17} /></a>
          <div className="hero-trust"><span><Check size={15} /> اختيار بعناية</span><span><Truck size={15} /> توصيل بـ ٨٠ ج.م</span></div>
        </div>
        <div className="hero-visual"><div className="hero-photo-shape"><div className="editorial-frame"><span>من زستور</span><b>أناقة<br />كل يوم</b><small>اختيار بعناية</small></div></div><div className="hero-caption"><span>تفاصيل تهمك</span><span>اختيارات زستور</span></div><div className="hero-stamp">Z</div></div>
      </section>
      <section className="benefit-strip">
        <div><span className="benefit-icon"><ShieldCheck /></span><span><b>اختيار موثوق</b><small>قطع نختارها لك بعناية</small></span></div>
        <div><span className="benefit-icon"><Truck /></span><span><b>توصيل لكل مصر</b><small>رسوم ثابتة ٨٠ جنيه</small></span></div>
        <div><span className="benefit-icon"><Heart /></span><span><b>راحة في كل تفصيلة</b><small>مقاسات وألوان تناسبك</small></span></div>
      </section>
      <section className="collection-section" id="products">
        <div className="section-heading"><div><span className="eyebrow">مختارة لك</span><h2>تشكيلة زستور</h2><p>اختاري القطعة التي تشبهك.</p></div>
          <label className="search-box"><Search size={18} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحثي عن قطعة..." aria-label="ابحثي عن المنتجات" data-testid="input-product-search" /><kbd>بحث</kbd></label>
        </div>
        {productsQuery.isLoading ? <LoadingGrid /> : productsQuery.isError ? <div className="state-panel"><span className="state-symbol">!</span><h3>لم نتمكن من تحميل التشكيلة</h3><p>تحققي من اتصالك ثم أعيدي المحاولة.</p><button className="button button-outline" onClick={() => void productsQuery.refetch()} data-testid="button-retry-products">إعادة المحاولة</button></div> : filtered.length ? <div className="product-grid">{filtered.map((product) => <ProductCard key={product.id} product={product} />)}</div> : <div className="state-panel"><span className="state-symbol"><Search /></span><h3>{search ? 'لا توجد نتائج بهذا الاسم' : 'التشكيلة تستعد للوصول'}</h3><p>{search ? 'جرّبي كلمة بحث أخرى.' : 'ستجدين هنا كل اختيارات زستور الجديدة.'}</p></div>}
        {!productsQuery.isLoading && !productsQuery.isError && filtered.length > 0 && <div className="collection-foot"><span>عرض {filtered.length.toLocaleString('ar-EG')} من القطع</span><div className="fine-rule" /></div>}
      </section>
      <section className="promise"><div className="promise-number">Z</div><div><span className="eyebrow">وعد زستور</span><h2>تسوقي وأنتِ<br />مطمئنة.</h2><p>سعر القطعة واضح، تفاصيلها كاملة، ورسوم التوصيل ثابتة. اختاري ما تحبين واتركي الباقي علينا.</p><Link href="/track" className="text-link" data-testid="link-promise-track">تابعي طلبك في أي وقت <ArrowLeft size={16} /></Link></div><div className="promise-side"><span>من اختيارنا<br />إلى بابك</span><b>٨٠</b><small>جنيه رسوم توصيل</small></div></section>
    </main>
  </Shell>;
}

function ProductPage({ id }: { id: string }) {
  const query = useGetProduct(id, { query: { queryKey: getGetProductQueryKey(id) } });
  const { add } = useCart();
  const [color, setColor] = useState('');
  const [size, setSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const product = query.data;
  const variants = product?.variants ?? [];
  const colors = [...new Set(variants.map((variant) => variant.color))];
  const sizes = [...new Set(variants.map((variant) => variant.size))];
  const stockOf = (nextColor: string, nextSize: string) =>
    variants.find((variant) => variant.color === nextColor && variant.size === nextSize)?.stock ?? 0;
  const selectedStock = stockOf(color, size);
  useEffect(() => {
    if (product) {
      const firstAvailable = product.variants.find((variant) => variant.stock > 0) ?? product.variants[0];
      setColor(firstAvailable?.color || ''); setSize(firstAvailable?.size || ''); setQuantity(1);
    }
  }, [product?.id]);
  const chooseOption = (nextColor: string, nextSize: string) => {
    setColor(nextColor); setSize(nextSize); setAdded(false);
    setQuantity((current) => Math.max(1, Math.min(current, stockOf(nextColor, nextSize))));
  };
  const chooseColor = (nextColor: string) => {
    const keepSize = stockOf(nextColor, size) > 0 ? size : (sizes.find((item) => stockOf(nextColor, item) > 0) ?? size);
    chooseOption(nextColor, keepSize);
  };
  if (query.isLoading) return <Shell><main className="page-container"><div className="detail-skeleton" /></main></Shell>;
  if (query.isError || !product) return <Shell><main className="page-container"><div className="state-panel"><h2>لم نعثر على هذه القطعة</h2><p>قد تكون غير متاحة الآن.</p><Link href="/" className="button button-primary">العودة للتشكيلة</Link></div></main></Shell>;
  return <Shell><main className="page-container">
    <div className="breadcrumbs"><Link href="/">الرئيسية</Link><span>/</span><span>{product.name}</span></div>
    <div className="detail-layout"><div className="detail-image"><ProductImage product={product} /></div><div className="detail-copy">
      <span className="eyebrow">اختيار زستور</span><h1 data-testid="text-product-title">{product.name}</h1><div className="detail-price" data-testid="text-product-detail-price">{money(quantity > 1 ? product.priceBulk : product.priceSingle)}</div>
      <p className="detail-description">{product.description}</p><div className="detail-stock" data-testid="text-selected-stock">{selectedStock > 0 ? <><span className="stock-dot" /> متوفر — {selectedStock.toLocaleString('ar-EG')} قطعة باللون والمقاس المختارين</> : 'هذا الاختيار غير متوفر حاليًا'}</div>
      {colors.length > 0 && <fieldset className="option-group"><legend>اللون <b>{color}</b></legend><div className="option-list">{colors.map((item) => { const available = variants.some((variant) => variant.color === item && variant.stock > 0); return <button key={item} onClick={() => chooseColor(item)} disabled={!available} className={`option-pill ${color === item ? 'selected' : ''} ${available ? '' : 'sold-out'}`} data-testid={`button-color-${item}`}>{available ? item : `${item} (نفد)`}</button>; })}</div></fieldset>}
      {sizes.length > 0 && <fieldset className="option-group"><legend>المقاس <b>{size}</b></legend><div className="option-list">{sizes.map((item) => { const available = stockOf(color, item) > 0; return <button key={item} onClick={() => chooseOption(color, item)} disabled={!available} className={`option-pill ${size === item ? 'selected' : ''} ${available ? '' : 'sold-out'}`} data-testid={`button-size-${item}`}>{available ? item : `${item} (نفد)`}</button>; })}</div></fieldset>}
      <div className="purchase-row"><div className="quantity-stepper"><button aria-label="تقليل الكمية" onClick={() => setQuantity(Math.max(1, quantity - 1))} data-testid="button-quantity-minus"><Minus size={16} /></button><span data-testid="text-quantity">{quantity.toLocaleString('ar-EG')}</span><button aria-label="زيادة الكمية" onClick={() => setQuantity(Math.min(selectedStock, quantity + 1))} data-testid="button-quantity-plus"><Plus size={16} /></button></div>
        <button className="button button-primary add-button" disabled={selectedStock < 1} onClick={() => { add(product, quantity, color, size); setAdded(true); }} data-testid="button-add-to-cart">{added ? <><Check size={18} /> أضيفت إلى السلة</> : <><ShoppingBag size={18} /> أضيفي إلى السلة</>}</button></div>
      <div className="detail-assurances"><span><Truck /> التوصيل ٨٠ ج.م</span><span><ShieldCheck /> تجربة تسوق موثوقة</span></div>
    </div></div>
  </main></Shell>;
}

function CartPage() {
  const { items, remove, update } = useCart();
  const subtotal = items.reduce((sum, line) => sum + (line.quantity > 1 ? line.product.priceBulk : line.product.priceSingle) * line.quantity, 0);
  return <Shell><main className="page-container narrow-page"><div className="page-title"><span className="eyebrow">اختياراتك</span><h1>سلة التسوق</h1><p>راجعي القطع قبل إتمام طلبك.</p></div>
    {!items.length ? <div className="empty-cart"><div className="empty-icon"><ShoppingBag /></div><h2>سلتك تنتظر اختيارك</h2><p>ابدئي باكتشاف قطع زستور المختارة.</p><Link href="/" className="button button-primary" data-testid="link-empty-cart-shop">تصفحي التشكيلة <ArrowLeft size={17} /></Link></div> :
      <div className="cart-layout"><div className="cart-lines">{items.map((line) => {
        const key = `${line.product.id}:${line.color}:${line.size}`;
        const unitPrice = line.quantity > 1 ? line.product.priceBulk : line.product.priceSingle;
        return <article className="cart-line" key={key} data-testid={`row-cart-item-${line.product.id}`}><Link className="cart-thumb" href={`/product/${line.product.id}`}><ProductImage product={line.product} /></Link><div className="cart-line-main"><Link href={`/product/${line.product.id}`} className="cart-product-name">{line.product.name}</Link><span>اللون: {line.color} <i>·</i> المقاس: {line.size}</span><strong>{money(unitPrice * line.quantity)}</strong></div><div className="cart-line-actions"><div className="quantity-stepper compact"><button onClick={() => update(key, line.quantity - 1)} aria-label="تقليل الكمية" data-testid={`button-cart-minus-${line.product.id}`}><Minus size={14} /></button><span>{line.quantity.toLocaleString('ar-EG')}</span><button onClick={() => update(key, line.quantity + 1)} aria-label="زيادة الكمية" data-testid={`button-cart-plus-${line.product.id}`}><Plus size={14} /></button></div><button className="remove-link" onClick={() => remove(key)} data-testid={`button-remove-cart-${line.product.id}`}>حذف</button></div></article>;
      })}</div><aside className="summary-card"><h2>ملخص الطلب</h2><div className="summary-row"><span>قيمة القطع</span><b>{money(subtotal)}</b></div><div className="summary-row"><span>التوصيل</span><b>{money(80)}</b></div><div className="summary-total"><span>الإجمالي المتوقع</span><b>{money(subtotal + 80)}</b></div><p className="summary-note">يتم تأكيد قيمة الطلب النهائية عند إتمامه.</p><Link href="/checkout" className="button button-primary full-button" data-testid="button-proceed-checkout">متابعة إتمام الطلب <ArrowLeft size={17} /></Link><Link href="/" className="back-to-shop" data-testid="link-continue-shopping">متابعة التسوق</Link></aside></div>}
  </main></Shell>;
}

function CheckoutPage() {
  const { items, clear } = useCart();
  const createOrder = useCreateOrder();
  const queryClient = useQueryClient();
  const [fields, setFields] = useState({ customerName: '', phone: '', address: '' });
  const [receipt, setReceipt] = useState<Awaited<ReturnType<typeof createOrder.mutateAsync>> | null>(null);
  const [error, setError] = useState('');
  const subtotal = items.reduce((sum, line) => sum + (line.quantity > 1 ? line.product.priceBulk : line.product.priceSingle) * line.quantity, 0);
  const onSubmit = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (!items.length) { setError('أضيفي قطعة واحدة على الأقل قبل إتمام الطلب.'); return; }
    const order: OrderInput = { ...fields, items: items.map((line) => ({ productId: line.product.id, quantity: line.quantity, color: line.color, size: line.size })) };
    createOrder.mutate({ data: order }, { onSuccess: (data) => {
      setReceipt(data); clear();
      void queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
      void queryClient.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
    }, onError: () => setError('تعذر تسجيل الطلب الآن. راجعي البيانات وحاولي مرة أخرى.') });
  };
  if (receipt) return <Shell><main className="page-container narrow-page"><div className="success-card"><span className="success-mark"><Check /></span><span className="eyebrow">وصلنا طلبك</span><h1>شكرًا لاختيارك زستور</h1><p>سنتواصل معك لتأكيد التفاصيل قبل الشحن.</p><div className="receipt-number"><span>رقم الطلب</span><b data-testid="text-order-number">{receipt.orderNo}</b></div><div className="summary-row"><span>إجمالي الطلب</span><b>{money(receipt.total)}</b></div><div className="summary-row"><span>التوصيل</span><b>{money(receipt.deliveryFee)}</b></div><div className="receipt-actions"><Link href={`/track`} className="button button-primary" data-testid="link-track-after-order">تابعي طلبك</Link><Link href="/" className="button button-outline">العودة للتسوق</Link></div></div></main></Shell>;
  return <Shell><main className="page-container narrow-page"><div className="page-title"><span className="eyebrow">خطوة أخيرة</span><h1>إتمام الطلب</h1><p>أدخلي بيانات التوصيل وسنتولى الباقي.</p></div><div className="checkout-layout"><form className="checkout-form" onSubmit={onSubmit}>
    <h2><span>١</span> بيانات التوصيل</h2><label>الاسم بالكامل<input required minLength={2} value={fields.customerName} onChange={(e) => setFields({ ...fields, customerName: e.target.value })} placeholder="اكتبي اسمك" data-testid="input-customer-name" /></label>
    <label>رقم الهاتف<input required minLength={6} type="tel" dir="ltr" value={fields.phone} onChange={(e) => setFields({ ...fields, phone: e.target.value })} placeholder="01xxxxxxxxx" data-testid="input-customer-phone" /></label>
    <label>عنوان التوصيل<textarea required minLength={4} value={fields.address} onChange={(e) => setFields({ ...fields, address: e.target.value })} placeholder="المحافظة، المنطقة، الشارع، وأقرب علامة مميزة" data-testid="input-customer-address" /></label>
    {error && <p className="form-error" role="alert" data-testid="status-checkout-error">{error}</p>}
    <button className="button button-primary full-button" disabled={createOrder.isPending || !items.length} data-testid="button-place-order">{createOrder.isPending ? 'جارٍ تسجيل طلبك...' : 'تأكيد الطلب'}</button><p className="secure-note"><ShieldCheck size={16} /> بياناتك تستخدم لإتمام التوصيل فقط.</p>
  </form><aside className="summary-card"><h2>ملخص القطع</h2>{items.map((line) => <div className="checkout-item" key={`${line.product.id}:${line.color}:${line.size}`}><span>{line.product.name} <small>× {line.quantity.toLocaleString('ar-EG')}</small><small>{line.color} · {line.size}</small></span><b>{money((line.quantity > 1 ? line.product.priceBulk : line.product.priceSingle) * line.quantity)}</b></div>)}<div className="summary-row"><span>القطع</span><b>{money(subtotal)}</b></div><div className="summary-row"><span>التوصيل الثابت</span><b>{money(80)}</b></div><div className="summary-total"><span>الإجمالي المتوقع</span><b>{money(subtotal + 80)}</b></div></aside></div></main></Shell>;
}

function TrackPage() {
  const [form, setForm] = useState({ orderNo: '', phone: '' });
  const [params, setParams] = useState({ orderNo: '', phone: '' });
  const queryKey = getTrackOrderQueryKey(params);
  const track = useTrackOrder(params, { query: { enabled: Boolean(params.orderNo && params.phone), queryKey, retry: false } });
  const submit = (event: FormEvent) => { event.preventDefault(); setParams({ orderNo: form.orderNo.trim(), phone: form.phone.trim() }); };
  return <Shell><main className="page-container narrow-page"><div className="page-title"><span className="eyebrow">على الطريق إليك</span><h1>تتبّع طلبك</h1><p>أدخلي رقم الطلب ورقم الهاتف المسجل لمتابعة حالته.</p></div>
    <form className="track-form" onSubmit={submit}><label>رقم الطلب<input required value={form.orderNo} onChange={(e) => setForm({ ...form, orderNo: e.target.value })} placeholder="مثال: ZS-12345" data-testid="input-track-order-number" /></label><label>رقم الهاتف<input required type="tel" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="رقم الهاتف الذي سجلتِ به" data-testid="input-track-phone" /></label><button className="button button-primary full-button" disabled={track.isFetching} data-testid="button-track-order">{track.isFetching ? 'جارٍ البحث...' : 'عرض حالة الطلب'}</button></form>
    {track.isFetching && <div className="track-result loading-result"><div className="skeleton-line" /><div className="skeleton-line short" /></div>}
    {track.isError && <div className="track-error" role="alert" data-testid="status-track-error"><span>لم نعثر على الطلب بهذه البيانات.</span><small>تأكدي من رقم الطلب ورقم الهاتف وحاولي مرة أخرى.</small></div>}
    {track.data && <div className="track-result" data-testid="panel-tracked-order"><div className="track-result-head"><span className="eyebrow">طلب رقم {track.data.orderNo}</span><span className="status-badge">{statusName(track.data.status)}</span></div><h2>أهلًا {track.data.customerName}</h2><div className="track-progress"><div className={`progress-step ${['received','preparing','out_for_delivery','delivered'].includes(track.data.status) ? 'done' : ''}`}><i /><span>تم الاستلام</span></div><div className={`progress-step ${['preparing','out_for_delivery','delivered'].includes(track.data.status) ? 'done' : ''}`}><i /><span>التجهيز</span></div><div className={`progress-step ${['out_for_delivery','delivered'].includes(track.data.status) ? 'done' : ''}`}><i /><span>التوصيل</span></div></div>{track.data.shippingLocation && <p className="shipping-location"><Truck size={17} /> موقع الشحنة: {track.data.shippingLocation}</p>}<div className="tracked-lines">{track.data.items.map((line, index) => <div key={`${line.productId}-${index}`}><span>{line.name} <small>× {line.quantity.toLocaleString('ar-EG')} · {line.color} · {line.size}</small></span><b>{money(line.lineTotal)}</b></div>)}</div><div className="summary-row"><span>قيمة القطع</span><b>{money(track.data.subtotal)}</b></div><div className="summary-row"><span>التوصيل</span><b>{money(track.data.deliveryFee)}</b></div><div className="summary-total"><span>الإجمالي</span><b>{money(track.data.total)}</b></div></div>}
  </main></Shell>;
}

function AdminGate() {
  const { isLoaded, isSignedIn, user } = useUser();
  if (!isLoaded) return <div className="auth-loading"><div className="skeleton-line" /><div className="skeleton-line short" /></div>;
  if (!isSignedIn) return <Shell><main className="page-container narrow-page"><div className="admin-gate"><CircleUserRound size={34} /><span className="eyebrow">مساحة إدارة زستور</span><h1>تسجيل الدخول مطلوب</h1><p>تحتاجين إلى تسجيل الدخول بحساب المالك لعرض لوحة الإدارة.</p><Link href="/sign-in" className="button button-primary" data-testid="link-admin-sign-in">تسجيل الدخول</Link></div></main></Shell>;
  return <AdminDashboard owner={user?.fullName || user?.primaryEmailAddress?.emailAddress || 'المالك'} />;
}
function ageStatusLabel(status: AdminOrder['ageStatus']) {
  if (status === 'new') return 'جديد';
  if (status === 'old') return 'قديم';
  if (status === 'parked') return 'مركون';
  return '';
}
function AdminInventoryPanel() {
  const inventory = useGetAdminInventory();
  return <section className="admin-panel">
    <div className="panel-header"><div><h2>الجرد</h2><p>الطلبات المسلّمة فقط تدخل في عدد المبيعات والعمولة.</p></div><button className="button button-outline button-small" onClick={() => void inventory.refetch()} disabled={inventory.isFetching}>تحديث</button></div>
    {inventory.isLoading ? <div className="state-panel"><h3>جارٍ تحميل الجرد...</h3></div> : inventory.isError ? <div className="state-panel"><h3>تعذر تحميل بيانات الجرد</h3><button className="button button-outline" onClick={() => void inventory.refetch()}>إعادة المحاولة</button></div> : inventory.data && <>
      <div className="inventory-metrics"><div className="metric-card"><span>إجمالي القطع المسلّمة</span><b>{inventory.data.soldUnits.toLocaleString('ar-EG')}</b><small>من كل المنتجات</small></div><div className="metric-card featured"><span>إجمالي العمولة</span><b>{money(inventory.data.totalCommission)}</b><small>ج.م · خاصة بالإدارة</small></div></div>
      {inventory.data.products.length ? <div className="orders-table-wrap"><table className="orders-table inventory-table"><thead><tr><th>المنتج</th><th>عدد القطع المسلّمة</th><th>إجمالي العمولة</th></tr></thead><tbody>{inventory.data.products.map((product) => <tr key={product.productId}><td><b>{product.productName}</b></td><td>{product.soldQuantity.toLocaleString('ar-EG')}</td><td><b>{money(product.commissionTotal)}</b></td></tr>)}</tbody></table></div> : <div className="state-panel"><h3>لا توجد منتجات في الجرد</h3></div>}
    </>}
  </section>;
}
function AdminOrdersPanel({
  orders,
  shipping,
  isError,
  isDeleting,
  isChanging,
  onRetry,
  onDeleteAll,
  onShippingChange,
  onChangeStatus,
}: {
  orders: AdminOrder[];
  shipping: Record<string, string>;
  isError: boolean;
  isDeleting: boolean;
  isChanging: boolean;
  onRetry: () => void;
  onDeleteAll: () => void;
  onShippingChange: (orderId: string, value: string) => void;
  onChangeStatus: (order: AdminOrder, status: OrderUpdate['status']) => void;
}) {
  return <section className="admin-panel">
    <div className="panel-header">
      <div><h2>طلبات المتجر</h2><p>تابعي حالة الشحن وعمر الطلب.</p></div>
      <div className="order-panel-actions">
        <span>{orders.length.toLocaleString('ar-EG')} طلب</span>
        <button className="button button-danger button-small" onClick={onDeleteAll} disabled={isDeleting || !orders.length} data-testid="button-delete-all-orders">
          {isDeleting ? 'جارٍ الحذف...' : 'حذف كل الطلبات'}
        </button>
      </div>
    </div>
    {isError ? <div className="state-panel"><h3>تعذر تحميل الطلبات</h3><button className="button button-outline" onClick={onRetry}>إعادة المحاولة</button></div> : orders.length ? <div className="orders-table-wrap"><table className="orders-table"><thead><tr><th>رقم الطلب</th><th>العميل</th><th>التفاصيل</th><th>الإجمالي</th><th>حالة الطلب</th><th>تحديث الحالة</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id} data-testid={`row-admin-order-${order.id}`}><td><b>{order.orderNo}</b><small>{new Date(order.createdAt).toLocaleDateString('ar-EG', { timeZone: 'Africa/Cairo' })}</small></td><td><b>{order.customerName}</b><small dir="ltr">{order.phone}</small><small>{order.address}</small></td><td>{order.items.map((line, i) => <small key={`${line.productId}-${i}`}>{line.name} × {line.quantity.toLocaleString('ar-EG')} — {line.color} / {line.size}</small>)}</td><td><b>{money(order.total)}</b></td><td><span className="status-badge">{statusName(order.status)}</span>{order.ageStatus && <span className={`age-status-badge age-${order.ageStatus}`}>{ageStatusLabel(order.ageStatus)}</span>}{order.shippingLocation && <small>{order.shippingLocation}</small>}</td><td><label className="shipping-input"><span>موقع الشحنة</span><input value={shipping[order.id] ?? order.shippingLocation ?? ''} onChange={(e) => onShippingChange(order.id, e.target.value)} placeholder="موقع الشحنة" data-testid={`input-shipping-location-${order.id}`} /></label><select defaultValue="" disabled={isChanging} onChange={(e) => { if (e.target.value) onChangeStatus(order, e.target.value as OrderUpdate['status']); e.currentTarget.value = ''; }} aria-label="تحديث حالة الطلب" data-testid={`select-order-status-${order.id}`}><option value="" disabled>تحديث الحالة</option><option value="received">تم استلام الطلب</option><option value="preparing">قيد التجهيز</option><option value="out_for_delivery">خرج للتوصيل</option><option value="delivered">تم التوصيل</option><option value="cancelled">إلغاء الطلب</option></select></td></tr>)}</tbody></table></div> : <div className="state-panel"><span className="state-symbol"><Package /></span><h3>لا توجد طلبات بعد</h3><p>ستظهر الطلبات الجديدة هنا عند تسجيلها.</p></div>}
  </section>;
}
function AdminProductsPanel({
  products,
  isLoading,
  isError,
  onRetry,
  onCreate,
  onEdit,
  onDelete,
}: {
  products: AdminProduct[] | undefined;
  isLoading: boolean;
  isError: boolean;
  onRetry: () => void;
  onCreate: () => void;
  onEdit: (product: AdminProduct) => void;
  onDelete: (product: AdminProduct) => void;
}) {
  return <section className="admin-panel">
    <div className="panel-header"><div><h2>منتجات زستور</h2><p>الأسعار والمخزون وإعدادات العمولة الخاصة بالإدارة.</p></div><span>{(products || []).length.toLocaleString('ar-EG')} قطعة</span></div>
    {isLoading ? <LoadingGrid /> : isError ? <div className="state-panel"><h3>تعذر تحميل المنتجات</h3><button className="button button-outline" onClick={onRetry}>إعادة المحاولة</button></div> : products?.length ? <div className="admin-product-list">{products.map((product) => <div className="admin-product-row" key={product.id} data-testid={`row-admin-product-${product.id}`}><div className="admin-product-thumb"><ProductImage product={product} /></div><div className="admin-product-name"><b>{product.name}</b><small>{product.colors.join('، ')} · {product.sizes.join('، ')}</small></div><span>{money(product.priceSingle)}</span><span className={product.stock < 5 ? 'low-stock' : ''}>المخزون: {product.stock.toLocaleString('ar-EG')}</span><div className="admin-product-actions"><button className="button button-outline button-small" onClick={() => onEdit(product)} data-testid={`button-edit-product-${product.id}`}>تعديل</button><button className="button button-danger button-small" onClick={() => onDelete(product)} data-testid={`button-delete-product-${product.id}`}>حذف</button></div></div>)}</div> : <div className="state-panel"><span className="state-symbol"><ShoppingBag /></span><h3>لا توجد منتجات بعد</h3><p>أضيفي أول قطعة لتظهر في التشكيلة.</p><button className="button button-primary" onClick={onCreate}>إضافة قطعة</button></div>}
  </section>;
}
function AdminDashboard({ owner }: { owner: string }) {
  const queryClient = useQueryClient();
  const summary = useGetAdminSummary();
  const ordersQuery = useListAdminOrders({ query: { queryKey: getListAdminOrdersQueryKey(), refetchInterval: 60_000 } });
  const orders = {
    ...ordersQuery,
    refetch: () =>
      queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() }),
  };
  const products = useListAdminProducts();
  const updateOrder = useUpdateAdminOrder();
  const deleteAllOrders = useDeleteAllAdminOrders();
  const createProduct = useCreateAdminProduct();
  const updateProduct = useUpdateAdminProduct();
  const deleteProduct = useDeleteAdminProduct();
  const { signOut } = useClerk();
  const [section, setSection] = useState<'orders' | 'products' | 'inventory'>('orders');
  const [editing, setEditing] = useState<AdminProduct | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const emptyProduct: ProductInput = { name: '', description: '', priceSingle: 0, priceBulk: 0, commSingle: 0, commBulk: 0, colors: [], sizes: [], variants: [], image: '', stock: 0 };
  const [productForm, setProductForm] = useState<ProductInput>(emptyProduct);
  const [colorsText, setColorsText] = useState('');
  const [sizesText, setSizesText] = useState('');
  const [stockGrid, setStockGrid] = useState<Record<string, number>>({});
  const [imageBusy, setImageBusy] = useState(false);
  const colorList = parseList(colorsText);
  const sizeList = parseList(sizesText);
  const totalStock = colorList.reduce((sum, color) => sum + sizeList.reduce((inner, size) => inner + (stockGrid[variantKey(color, size)] ?? 0), 0), 0);
  const [shipping, setShipping] = useState<Record<string, string>>({});
  const invalidateProducts = () => { void queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getListAdminProductsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); };
  const adminError = summary.error;
  const errorMessage = adminError instanceof Error ? adminError.message : '';
  const isUnauthorized = errorMessage.includes('401') || errorMessage.includes('403') || errorMessage.toLowerCase().includes('unauthor');
  const openCreate = () => { setEditing(null); setProductForm(emptyProduct); setColorsText(''); setSizesText(''); setStockGrid({}); setShowForm(true); setError(''); };
  const openEdit = (product: AdminProduct) => {
    setEditing(product); setProductForm({ ...product });
    setColorsText(product.colors.join('، ')); setSizesText(product.sizes.join('، '));
    setStockGrid(Object.fromEntries(product.variants.map((variant) => [variantKey(variant.color, variant.size), variant.stock])));
    setShowForm(true); setError('');
  };
  const onImageFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setImageBusy(true); setError('');
    try {
      const dataUrl = await imageFileToDataUrl(file);
      setProductForm((form) => ({ ...form, image: dataUrl }));
    } catch {
      setError('تعذر قراءة الصورة. جرّبي صورة أخرى.');
    } finally {
      setImageBusy(false);
    }
  };
  const saveProduct = (event: FormEvent) => {
    event.preventDefault(); setError('');
    if (!colorList.length || !sizeList.length) { setError('أضيفي لونًا ومقاسًا واحدًا على الأقل.'); return; }
    const variants = colorList.flatMap((color) => sizeList.map((size) => ({ color, size, stock: stockGrid[variantKey(color, size)] ?? 0 })));
    const data: ProductInput = { ...productForm, colors: colorList, sizes: sizeList, variants, stock: variants.reduce((sum, variant) => sum + variant.stock, 0) };
    const onSuccess = () => { setShowForm(false); setNotice(editing ? 'تم تحديث القطعة.' : 'تمت إضافة القطعة.'); invalidateProducts(); };
    if (editing) updateProduct.mutate({ id: editing.id, data }, { onSuccess, onError: () => setError('تعذر حفظ التغييرات. تحققي من صلاحيات الحساب والبيانات.') });
    else createProduct.mutate({ data }, { onSuccess, onError: () => setError('تعذر إضافة القطعة. تحققي من صلاحيات الحساب والبيانات.') });
  };
  const changeOrder = (order: AdminOrder, status: OrderUpdate['status']) => {
    updateOrder.mutate({ id: order.id, data: { status, shippingLocation: shipping[order.id] || order.shippingLocation || null } }, {
      onSuccess: () => { setNotice('تم تحديث حالة الطلب.'); void queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() }); void queryClient.invalidateQueries({ queryKey: getGetAdminInventoryQueryKey() }); },
      onError: () => setError('تعذر تحديث الطلب. لا يملك الحساب صلاحية التعديل أو حدث خطأ في الاتصال.'),
    });
  };
  const handleDelete = (product: AdminProduct) => {
    if (!window.confirm(`هل تريدين حذف "${product.name}"؟`)) return;
    deleteProduct.mutate({ id: product.id }, { onSuccess: () => { setNotice('تم حذف القطعة.'); invalidateProducts(); }, onError: () => setError('تعذر حذف القطعة. راجعي صلاحيات الحساب.') });
  };
  const handleDeleteAllOrders = () => {
    const count = orders.data?.length ?? 0;
    if (!count) return;
    const confirmation = window.prompt(
      `سيتم حذف جميع الطلبات (${count}) نهائيًا، وستُعاد كميات الطلبات غير المسلّمة إلى المخزون. اكتب «حذف الطلبات» للتأكيد:`,
    );
    if (confirmation !== 'حذف الطلبات') return;
    deleteAllOrders.mutate(undefined, {
      onSuccess: (result) => {
        setNotice(`تم حذف ${result.deletedCount.toLocaleString('ar-EG')} طلب وإعادة ${result.restockedUnits.toLocaleString('ar-EG')} قطعة إلى المخزون.`);
        void queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetAdminInventoryQueryKey() });
      },
      onError: () => setError('تعذر حذف الطلبات. راجعي صلاحيات الحساب وحاولي مرة أخرى.'),
    });
  };
  if (summary.isLoading || orders.isLoading) return <div dir="rtl" className="admin-loading"><div className="skeleton-line" /><div className="admin-stat-skeletons">{[1, 2, 3, 4].map((n) => <div className="skeleton-block" key={n} />)}</div></div>;
  return <div className="admin-shell" dir="rtl"><aside className="admin-sidebar"><Link href="/" className="admin-brand" data-testid="link-admin-home"><BrandMark /><span><b>ZSTORE</b><small>STORE MANAGEMENT</small></span></Link><div className="admin-menu-label">مساحة العمل</div><button className={section === 'orders' ? 'admin-nav active' : 'admin-nav'} onClick={() => setSection('orders')} data-testid="button-admin-orders"><Package size={18} /> الطلبات</button><button className={section === 'products' ? 'admin-nav active' : 'admin-nav'} onClick={() => setSection('products')} data-testid="button-admin-products"><ShoppingBag size={18} /> المنتجات</button><button className={section === 'inventory' ? 'admin-nav active' : 'admin-nav'} onClick={() => setSection('inventory')} data-testid="button-admin-inventory"><ClipboardList size={18} /> الجرد</button><div className="admin-user"><span className="owner-avatar">{owner.slice(0, 1)}</span><div><b>{owner}</b><button onClick={() => void signOut({ redirectUrl: basePath || '/' })} data-testid="button-admin-sign-out">تسجيل الخروج</button></div></div></aside>
    <main className="admin-main"><div className="admin-topline"><span>لوحة المتجر / إدارة زستور</span><Link href="/" data-testid="link-view-store">عرض المتجر <ArrowLeft size={15} /></Link></div>
      {adminError ? <div className="admin-error-state" role="alert" data-testid="status-admin-error"><span className="state-symbol">!</span><h1>{isUnauthorized ? 'لا توجد صلاحية للوصول' : 'تعذر تحميل لوحة الإدارة'}</h1><p>{isUnauthorized ? 'تم تسجيل الدخول، لكن الخادم لم يمنح هذا الحساب صلاحية المالك. لا يمكن منح صلاحية الإدارة من المتصفح.' : 'حدث خطأ أثناء التواصل مع الخدمة. حاولي إعادة تحميل البيانات.'}</p><button className="button button-outline" onClick={() => { void summary.refetch(); void orders.refetch(); }} data-testid="button-admin-retry">إعادة المحاولة</button></div> :
      <>
        <div className="admin-heading"><div><span className="eyebrow">مساحة المالك</span><h1>{section === 'orders' ? 'صباح الخير، ' : section === 'products' ? 'إدارة المنتجات، ' : 'ملخص الجرد، '}<em>{owner.split(' ')[0]}</em></h1><p>{section === 'orders' ? 'هذه صورة واضحة عن حركة متجرك اليوم.' : section === 'products' ? 'أضيفي القطع إلى التشكيلة وأديري تفاصيلها.' : 'مبيعات المنتجات المسلّمة وإجمالي العمولة الخاصة بك.'}</p></div>{section === 'products' && <button className="button button-primary" onClick={openCreate} data-testid="button-create-product"><Plus size={17} /> إضافة قطعة</button>}</div>
        {summary.data && <div className="admin-metrics"><div className="metric-card"><span>إجمالي الطلبات</span><b data-testid="text-admin-total-orders">{summary.data.totalOrders.toLocaleString('ar-EG')}</b><small>منذ بداية المتجر</small></div><div className="metric-card"><span>طلبات نشطة</span><b data-testid="text-admin-active-orders">{summary.data.activeOrders.toLocaleString('ar-EG')}</b><small>تحتاج إلى متابعة</small></div><div className="metric-card"><span>عدد المنتجات</span><b data-testid="text-admin-total-products">{summary.data.totalProducts.toLocaleString('ar-EG')}</b><small>{summary.data.lowStockProducts.toLocaleString('ar-EG')} قطع بمخزون منخفض</small></div><div className="metric-card featured"><span>إجمالي الإيرادات</span><b data-testid="text-admin-revenue">{money(summary.data.revenue)}</b><small>قيمة الطلبات المسجلة</small></div></div>}
        {notice && <div className="admin-notice" role="status" data-testid="status-admin-notice"><Check size={16} />{notice}<button onClick={() => setNotice('')} aria-label="إغلاق" data-testid="button-dismiss-notice"><X size={15} /></button></div>}
        {error && <div className="admin-form-error" role="alert" data-testid="status-admin-action-error">{error}<button onClick={() => setError('')} aria-label="إغلاق" data-testid="button-dismiss-error"><X size={15} /></button></div>}
        {section === 'orders' ? <AdminOrdersPanel orders={orders.data || []} shipping={shipping} isError={orders.isError} isDeleting={deleteAllOrders.isPending} isChanging={updateOrder.isPending} onRetry={() => { void orders.refetch(); }} onDeleteAll={handleDeleteAllOrders} onShippingChange={(orderId, value) => setShipping((current) => ({ ...current, [orderId]: value }))} onChangeStatus={changeOrder} /> :
          section === 'inventory' ? <AdminInventoryPanel /> :
            <AdminProductsPanel products={products.data} isLoading={products.isLoading} isError={products.isError} onRetry={() => { void products.refetch(); }} onCreate={openCreate} onEdit={openEdit} onDelete={handleDelete} />}
      </>}
    </main>
    {showForm && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowForm(false); }}><form className="product-modal" onSubmit={saveProduct}><div className="modal-head"><div><span className="eyebrow">إدارة التشكيلة</span><h2>{editing ? 'تعديل قطعة' : 'إضافة قطعة جديدة'}</h2></div><button type="button" className="icon-button" onClick={() => setShowForm(false)} aria-label="إغلاق" data-testid="button-close-product-form"><X /></button></div>
      <div className="product-form-grid"><label className="span-two">اسم القطعة<input required value={productForm.name} onChange={(e) => setProductForm({ ...productForm, name: e.target.value })} data-testid="input-admin-product-name" /></label><label className="span-two">الوصف<textarea value={productForm.description} onChange={(e) => setProductForm({ ...productForm, description: e.target.value })} data-testid="input-admin-product-description" /></label><label>سعر القطعة<input required min="0" type="number" value={productForm.priceSingle} onChange={(e) => setProductForm({ ...productForm, priceSingle: Number(e.target.value) })} data-testid="input-admin-price-single" /></label><label>سعر الجملة<input required min="0" type="number" value={productForm.priceBulk} onChange={(e) => setProductForm({ ...productForm, priceBulk: Number(e.target.value) })} data-testid="input-admin-price-bulk" /></label><label>العمولة على القطعة الواحدة (ج.م)<input required min="0" type="number" value={productForm.commSingle} onChange={(e) => setProductForm({ ...productForm, commSingle: Number(e.target.value) })} data-testid="input-admin-comm-single" /></label><label>العمولة على أكثر من قطعة (ج.م)<input required min="0" type="number" value={productForm.commBulk} onChange={(e) => setProductForm({ ...productForm, commBulk: Number(e.target.value) })} data-testid="input-admin-comm-bulk" /></label><label className="span-two">الألوان، افصلي بينها بفاصلة<input value={colorsText} onChange={(e) => setColorsText(e.target.value)} data-testid="input-admin-product-colors" /></label><label className="span-two">المقاسات، افصلي بينها بفاصلة<input value={sizesText} onChange={(e) => setSizesText(e.target.value)} data-testid="input-admin-product-sizes" /></label><div className="span-two stock-matrix-wrap"><span className="stock-matrix-title">الكمية المتاحة لكل لون ومقاس</span>{colorList.length && sizeList.length ? <div className="orders-table-wrap"><table className="stock-matrix"><thead><tr><th>اللون / المقاس</th>{sizeList.map((size) => <th key={size}>{size}</th>)}</tr></thead><tbody>{colorList.map((color) => <tr key={color}><th>{color}</th>{sizeList.map((size) => <td key={size}><input type="number" min="0" inputMode="numeric" aria-label={`${color} ${size}`} value={stockGrid[variantKey(color, size)] ?? 0} onChange={(e) => setStockGrid((grid) => ({ ...grid, [variantKey(color, size)]: Math.max(0, Math.floor(Number(e.target.value) || 0)) }))} data-testid={`input-stock-${color}-${size}`} /></td>)}</tr>)}</tbody></table></div> : <small>أضيفي الألوان والمقاسات أولًا لتظهر جدول الكميات.</small>}<small>إجمالي المخزون: {totalStock.toLocaleString('ar-EG')} قطعة</small></div><div className="span-two image-upload"><span>صورة القطعة</span>{productForm.image && <img src={productForm.image} alt="معاينة الصورة" className="image-preview" />}<div className="image-upload-actions"><label className="button button-outline button-small">{imageBusy ? 'جارٍ تجهيز الصورة...' : 'اختاري صورة من الجهاز أو الهاتف'}<input type="file" accept="image/*" hidden disabled={imageBusy} onChange={onImageFile} data-testid="input-admin-product-image-file" /></label>{productForm.image && <button type="button" className="button button-outline button-small" onClick={() => setProductForm((form) => ({ ...form, image: '' }))}>إزالة الصورة</button>}</div></div></div>{error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="button button-outline" onClick={() => setShowForm(false)}>إلغاء</button><button className="button button-primary" disabled={createProduct.isPending || updateProduct.isPending} data-testid="button-save-product">{createProduct.isPending || updateProduct.isPending ? 'جارٍ الحفظ...' : 'حفظ القطعة'}</button></div>
    </form></div>}
  </div>;
}

function SignInPage() { return <div dir="rtl" className="auth-page"><div className="auth-intro"><Link href="/" className="brand"><BrandMark /><span><b>ZSTORE</b><small>STYLE, SELECTED</small></span></Link><p>مساحة آمنة لإدارة المتجر.</p></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /> </div>; }
function SignUpPage() { return <div dir="rtl" className="auth-page"><div className="auth-intro"><Link href="/" className="brand"><BrandMark /><span><b>ZSTORE</b><small>STYLE, SELECTED</small></span></Link><p>أنشئي حسابك لتكوني جزءًا من زستور.</p></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>; }
function NotFoundPage() { return <Shell><main className="page-container narrow-page"><div className="state-panel"><span className="state-symbol">٤٠٤</span><h2>هذه الصفحة غير متاحة</h2><p>لنعد إلى اختيارات زستور.</p><Link className="button button-primary" href="/" data-testid="link-not-found-home">العودة للرئيسية</Link></div></main></Shell>; }
function ClerkCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserId = useRef<string | null | undefined>(undefined);
  useEffect(() => addListener(({ user }) => {
    const next = user?.id ?? null;
    if (prevUserId.current !== undefined && prevUserId.current !== next) qc.clear();
    prevUserId.current = next;
  }), [addListener, qc]);
  return null;
}
function RouterContent() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={appearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={arSA}
    routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}>
    <QueryClientProvider client={queryClient}><ClerkCacheInvalidator /><CartProvider><Switch>
      <Route path="/" component={Storefront} />
      <Route path="/product/:id">{(params) => <ProductPage id={params.id} />}</Route>
      <Route path="/cart" component={CartPage} />
      <Route path="/checkout" component={CheckoutPage} />
      <Route path="/track" component={TrackPage} />
      <Route path="/admin" component={AdminGate} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={NotFoundPage} />
    </Switch></CartProvider></QueryClientProvider>
  </ClerkProvider>;
}
function App() {
  return <WouterRouter base={basePath}><RouterContent /></WouterRouter>;
}
export default App;
