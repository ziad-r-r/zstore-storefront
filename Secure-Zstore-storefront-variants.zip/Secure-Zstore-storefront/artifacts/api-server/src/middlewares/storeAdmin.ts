import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";

export const requireStoreAdmin: RequestHandler = async (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "يرجى تسجيل الدخول أولاً." });
    return;
  }

  const configuredEmail = process.env.ZSTORE_ADMIN_EMAIL?.trim().toLowerCase();
  if (!configuredEmail) {
    res.status(503).json({ error: "لم يتم إعداد حساب مالك المتجر بعد." });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const primaryEmail = user.emailAddresses.find(
      (email) => email.id === user.primaryEmailAddressId,
    );
    if (
      primaryEmail?.verification?.status !== "verified" ||
      primaryEmail.emailAddress.trim().toLowerCase() !== configuredEmail
    ) {
      res.status(403).json({ error: "هذا الحساب غير مخوّل لإدارة المتجر." });
      return;
    }
    next();
  } catch (error) {
    req.log.error({ error }, "Unable to verify Zstore admin access");
    res.status(503).json({ error: "تعذّر التحقق من صلاحية إدارة المتجر." });
  }
};
