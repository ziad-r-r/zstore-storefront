import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import {
  GetProductParams,
  GetProductResponse,
  ListProductsResponse,
} from "@workspace/api-zod";
import { db, productsTable } from "@workspace/db";

const router: IRouter = Router();

function toPublicProduct(product: typeof productsTable.$inferSelect) {
  const { id, name, description, priceSingle, priceBulk, colors, sizes, image, stock, variants } = product;
  return { id, name, description, priceSingle, priceBulk, colors, sizes, image, stock, variants };
}

router.get("/products", async (_req, res): Promise<void> => {
  const products = await db.select().from(productsTable).orderBy(productsTable.createdAt);
  res.json(ListProductsResponse.parse(products.map(toPublicProduct)));
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, params.data.id));
  if (!product) {
    res.status(404).json({ error: "المنتج غير موجود." });
    return;
  }
  res.json(GetProductResponse.parse(toPublicProduct(product)));
});

export default router;
