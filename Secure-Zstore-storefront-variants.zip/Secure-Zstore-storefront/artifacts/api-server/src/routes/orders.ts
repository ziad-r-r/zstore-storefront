import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, eq, inArray } from "drizzle-orm";
import {
  CreateOrderBody,
  CreateOrderResponse,
  TrackOrderQueryParams,
  TrackOrderResponse,
} from "@workspace/api-zod";
import { db, ordersTable, productsTable, type StoredOrderLine } from "@workspace/db";
import { reserveStock, totalStock, type StockChange } from "../lib/variants";

const DELIVERY_FEE = 80;
const router: IRouter = Router();

class CheckoutError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

function normalizePhone(phone: string): string {
  return phone.replace(/\D/g, "");
}

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const receipt = await db.transaction(async (tx) => {
      const productIds = [...new Set(parsed.data.items.map((item) => item.productId))];
      // Lock the product rows so two checkouts cannot take the same last piece.
      const products = await tx
        .select()
        .from(productsTable)
        .where(inArray(productsTable.id, productIds))
        .for("update");
      const productsById = new Map(products.map((product) => [product.id, product]));

      if (productsById.size !== productIds.length) {
        throw new CheckoutError("أحد المنتجات لم يعد متاحاً.", 400);
      }

      const lines: StoredOrderLine[] = parsed.data.items.map((item) => {
        const product = productsById.get(item.productId);
        if (!product) {
          throw new CheckoutError("أحد المنتجات لم يعد متاحاً.", 400);
        }
        const isValidChoice = product.variants.some(
          (variant) => variant.color === item.color && variant.size === item.size,
        );
        if (!isValidChoice) {
          throw new CheckoutError("اختيار اللون أو المقاس غير صالح.", 400);
        }
        const unitPrice = item.quantity > 1 ? product.priceBulk : product.priceSingle;
        return {
          productId: product.id,
          name: product.name,
          quantity: item.quantity,
          color: item.color,
          size: item.size,
          unitPrice,
          lineTotal: unitPrice * item.quantity,
          unitCommission: item.quantity > 1 ? product.commBulk : product.commSingle,
        };
      });

      // Take stock out per product, per color and size combination.
      const changesByProduct = new Map<string, StockChange[]>();
      for (const item of parsed.data.items) {
        const changes = changesByProduct.get(item.productId) ?? [];
        changes.push({ color: item.color, size: item.size, quantity: item.quantity });
        changesByProduct.set(item.productId, changes);
      }
      for (const [productId, changes] of changesByProduct) {
        const product = productsById.get(productId);
        if (!product) continue;
        const result = reserveStock(product.variants, changes);
        if (!result.ok) {
          throw new CheckoutError(
            `الكمية المطلوبة من ${product.name} (${result.color} / ${result.size}) غير متاحة في المخزون.`,
            409,
          );
        }
        await tx
          .update(productsTable)
          .set({ variants: result.variants, stock: totalStock(result.variants) })
          .where(eq(productsTable.id, productId));
      }

      const subtotal = lines.reduce((sum, line) => sum + line.lineTotal, 0);
      const id = randomUUID();
      const orderNo = `ZS-${randomUUID().slice(0, 8).toUpperCase()}`;
      const [order] = await tx
        .insert(ordersTable)
        .values({
          id,
          orderNo,
          customerName: parsed.data.customerName.trim(),
          phone: parsed.data.phone.trim(),
          normalizedPhone: normalizePhone(parsed.data.phone),
          address: parsed.data.address.trim(),
          items: lines,
          subtotal,
          deliveryFee: DELIVERY_FEE,
          total: subtotal + DELIVERY_FEE,
        })
        .returning();

      return {
        id: order.id,
        orderNo: order.orderNo,
        total: order.total,
        deliveryFee: order.deliveryFee,
        status: order.status,
        createdAt: order.createdAt.toISOString(),
      };
    });

    res.status(201).json(CreateOrderResponse.parse(receipt));
  } catch (error) {
    if (error instanceof CheckoutError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    req.log.error({ error }, "Unable to create Zstore order");
    res.status(500).json({ error: "تعذّر إتمام الطلب. حاول مرة أخرى." });
  }
});

router.get("/orders/track", async (req, res): Promise<void> => {
  const parsed = TrackOrderQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(
      and(
        eq(ordersTable.orderNo, parsed.data.orderNo.trim().toUpperCase()),
        eq(ordersTable.normalizedPhone, normalizePhone(parsed.data.phone)),
      ),
    );
  if (!order) {
    res.status(404).json({ error: "لم نعثر على طلب بهذه البيانات." });
    return;
  }

  res.json(
    TrackOrderResponse.parse({
      orderNo: order.orderNo,
      customerName: order.customerName,
       items: order.items.map((line) => ({
         productId: line.productId,
         name: line.name,
         quantity: line.quantity,
         color: line.color,
         size: line.size,
         unitPrice: line.unitPrice,
         lineTotal: line.lineTotal,
       })),
      subtotal: order.subtotal,
      deliveryFee: order.deliveryFee,
      total: order.total,
      status: order.status,
      shippingLocation: order.shippingLocation,
      createdAt: order.createdAt.toISOString(),
    }),
  );
});

export default router;
