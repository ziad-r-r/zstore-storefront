import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  and,
  count,
  desc,
  eq,
  gte,
  lt,
  notInArray,
  sql,
  sum,
} from "drizzle-orm";
import {
  CreateAdminProductBody,
  CreateAdminProductResponse,
  DeleteAllAdminOrdersResponse,
  DeleteAdminProductParams,
  GetAdminInventoryResponse,
  GetAdminSummaryResponse,
  ListAdminOrdersResponse,
  ListAdminProductsResponse,
  UpdateAdminOrderBody,
  UpdateAdminOrderParams,
  UpdateAdminOrderResponse,
  UpdateAdminProductBody,
  UpdateAdminProductParams,
  UpdateAdminProductResponse,
} from "@workspace/api-zod";
import { db, ordersTable, productsTable } from "@workspace/db";
import { clearOrdersAndRestock } from "../lib/clearOrders";
import {
  normalizeVariants,
  releaseStock,
  totalStock,
  type StockChange,
} from "../lib/variants";
import { requireStoreAdmin } from "../middlewares/storeAdmin";

const router: IRouter = Router();
router.use("/admin", requireStoreAdmin);

type Transaction = Parameters<Parameters<typeof db.transaction>[0]>[0];

/** Puts stock back on a product's color/size combinations. Combinations the owner deleted are skipped. */
async function restoreVariantStock(
  tx: Transaction,
  productId: string,
  changes: StockChange[],
): Promise<boolean> {
  const [product] = await tx
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, productId))
    .for("update");
  if (!product) return false;

  const existing = changes.filter((change) =>
    product.variants.some(
      (variant) => variant.color === change.color && variant.size === change.size,
    ),
  );
  const result = releaseStock(product.variants, existing);
  if (!result.ok) return false;

  await tx
    .update(productsTable)
    .set({ variants: result.variants, stock: totalStock(result.variants) })
    .where(eq(productsTable.id, productId));
  return true;
}

/** Turns the admin's color/size/stock grid into the stored product fields. */
function variantFields(variants: { color: string; size: string; stock: number }[]) {
  const result = normalizeVariants(variants);
  if (!result.ok) return { ok: false as const, error: result.error };
  return {
    ok: true as const,
    fields: {
      variants: result.variants,
      colors: result.colors,
      sizes: result.sizes,
      stock: totalStock(result.variants),
    },
  };
}

function cairoDayNumber(date: Date): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Africa/Cairo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const value = (kind: Intl.DateTimeFormatPartTypes) =>
    Number(parts.find((part) => part.type === kind)?.value);
  return Date.UTC(value("year"), value("month") - 1, value("day")) / 86_400_000;
}

function ageStatus(createdAt: Date, status: string): "new" | "old" | "parked" | null {
  if (status === "delivered" || status === "cancelled") return null;
  const daysOld = Math.max(0, cairoDayNumber(new Date()) - cairoDayNumber(createdAt));
  if (daysOld === 0) return "new";
  if (daysOld === 1) return "old";
  return "parked";
}

router.get("/admin/summary", async (_req, res): Promise<void> => {
  const [[orders], [active], [products], [lowStock], [revenue]] = await Promise.all([
    db.select({ value: count() }).from(ordersTable),
    db
      .select({ value: count() })
      .from(ordersTable)
      .where(notInArray(ordersTable.status, ["delivered", "cancelled"])),
    db.select({ value: count() }).from(productsTable),
    db.select({ value: count() }).from(productsTable).where(lt(productsTable.stock, 3)),
    db
      .select({ value: sum(ordersTable.total) })
      .from(ordersTable)
      .where(notInArray(ordersTable.status, ["cancelled"])),
  ]);

  res.json(
    GetAdminSummaryResponse.parse({
      totalOrders: orders.value,
      activeOrders: active.value,
      totalProducts: products.value,
      lowStockProducts: lowStock.value,
      revenue: Number(revenue.value ?? 0),
    }),
  );
});

router.get("/admin/inventory", async (_req, res): Promise<void> => {
  const [products, deliveredOrders] = await Promise.all([
    db
      .select({
        id: productsTable.id,
        name: productsTable.name,
        commSingle: productsTable.commSingle,
        commBulk: productsTable.commBulk,
      })
      .from(productsTable),
    db
      .select({ items: ordersTable.items })
      .from(ordersTable)
      .where(eq(ordersTable.status, "delivered")),
  ]);

  const currentProducts = new Map(products.map((product) => [product.id, product]));
  const inventory = new Map<string, {
    productId: string;
    productName: string;
    soldQuantity: number;
    commissionTotal: number;
  }>(
    products.map((product) => [
      product.id,
      { productId: product.id, productName: product.name, soldQuantity: 0, commissionTotal: 0 },
    ]),
  );

  for (const order of deliveredOrders) {
    for (const item of order.items) {
      const currentProduct = currentProducts.get(item.productId);
      const entry = inventory.get(item.productId) ?? {
        productId: item.productId,
        productName: item.name,
        soldQuantity: 0,
        commissionTotal: 0,
      };
      const unitCommission =
        item.unitCommission ??
        (item.quantity > 1 ? currentProduct?.commBulk : currentProduct?.commSingle) ??
        0;
      entry.soldQuantity += item.quantity;
      entry.commissionTotal += unitCommission * item.quantity;
      inventory.set(item.productId, entry);
    }
  }

  const inventoryProducts = [...inventory.values()]
    .map((product) => ({
      ...product,
      commissionTotal: Math.round((product.commissionTotal + Number.EPSILON) * 100) / 100,
    }))
    .sort((a, b) => b.soldQuantity - a.soldQuantity || a.productName.localeCompare(b.productName));

  res.json(
    GetAdminInventoryResponse.parse({
      soldUnits: inventoryProducts.reduce((sum, product) => sum + product.soldQuantity, 0),
      totalCommission: Math.round(
        (inventoryProducts.reduce((sum, product) => sum + product.commissionTotal, 0) +
          Number.EPSILON) *
          100,
      ) / 100,
      products: inventoryProducts,
    }),
  );
});

router.get("/admin/orders", async (_req, res): Promise<void> => {
  const orders = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt));
  res.json(
    ListAdminOrdersResponse.parse(
      orders.map((order) => ({
        ...order,
        ageStatus: ageStatus(order.createdAt, order.status),
        items: order.items.map((line) => ({
          productId: line.productId,
          name: line.name,
          quantity: line.quantity,
          color: line.color,
          size: line.size,
          unitPrice: line.unitPrice,
          lineTotal: line.lineTotal,
        })),
        createdAt: order.createdAt.toISOString(),
      })),
    ),
  );
});

router.delete("/admin/orders", async (_req, res): Promise<void> => {
  const result = await clearOrdersAndRestock((work) =>
    db.transaction(async (tx) =>
      work({
        lockAndReadOrders: async () => {
          await tx.execute(sql`LOCK TABLE ${ordersTable} IN ACCESS EXCLUSIVE MODE`);
          return tx
            .select({ status: ordersTable.status, items: ordersTable.items })
            .from(ordersTable);
        },
        restockVariant: (productId, color, size, quantity) =>
          restoreVariantStock(tx, productId, [{ color, size, quantity }]),
        deleteAllOrders: async () => {
          const deletedOrders = await tx
            .delete(ordersTable)
            .returning({ id: ordersTable.id });
          return deletedOrders.length;
        },
      }),
    ),
  );

  res.json(DeleteAllAdminOrdersResponse.parse(result));
});

router.patch("/admin/orders/:id", async (req, res): Promise<void> => {
  const params = UpdateAdminOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateAdminOrderBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(ordersTable)
      .where(eq(ordersTable.id, params.data.id));
    if (!current) return { kind: "not-found" as const };
    if (current.status === "cancelled" && body.data.status !== "cancelled") {
      return { kind: "already-cancelled" as const };
    }

    if (current.status !== "cancelled" && body.data.status === "cancelled") {
      const changesByProduct = new Map<string, StockChange[]>();
      for (const item of current.items) {
        const changes = changesByProduct.get(item.productId) ?? [];
        changes.push({ color: item.color, size: item.size, quantity: item.quantity });
        changesByProduct.set(item.productId, changes);
      }
      for (const [productId, changes] of changesByProduct) {
        await restoreVariantStock(tx, productId, changes);
      }
    }

    const [updated] = await tx
      .update(ordersTable)
      .set({
        status: body.data.status,
        ...(body.data.shippingLocation !== undefined
          ? { shippingLocation: body.data.shippingLocation }
          : {}),
      })
      .where(eq(ordersTable.id, params.data.id))
      .returning();
    return { kind: "updated" as const, order: updated };
  });

  if (result.kind === "not-found") {
    res.status(404).json({ error: "الطلب غير موجود." });
    return;
  }
  if (result.kind === "already-cancelled") {
    res.status(409).json({ error: "لا يمكن إعادة تفعيل طلب ملغي." });
    return;
  }
  res.json(
    UpdateAdminOrderResponse.parse({
      ...result.order,
      ageStatus: ageStatus(result.order.createdAt, result.order.status),
      items: result.order.items.map((line) => ({
        productId: line.productId,
        name: line.name,
        quantity: line.quantity,
        color: line.color,
        size: line.size,
        unitPrice: line.unitPrice,
        lineTotal: line.lineTotal,
      })),
      createdAt: result.order.createdAt.toISOString(),
    }),
  );
});

router.get("/admin/products", async (_req, res): Promise<void> => {
  const products = await db.select().from(productsTable).orderBy(productsTable.createdAt);
  res.json(ListAdminProductsResponse.parse(products));
});

router.post("/admin/products", async (req, res): Promise<void> => {
  const body = CreateAdminProductBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const derived = variantFields(body.data.variants);
  if (!derived.ok) {
    res.status(400).json({ error: derived.error });
    return;
  }

  const [product] = await db
    .insert(productsTable)
    .values({ id: randomUUID(), ...body.data, ...derived.fields })
    .returning();
  res.status(201).json(CreateAdminProductResponse.parse(product));
});

router.patch("/admin/products/:id", async (req, res): Promise<void> => {
  const params = UpdateAdminProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdateAdminProductBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const derived = variantFields(body.data.variants);
  if (!derived.ok) {
    res.status(400).json({ error: derived.error });
    return;
  }

  const [product] = await db
    .update(productsTable)
    .set({ ...body.data, ...derived.fields, updatedAt: new Date() })
    .where(eq(productsTable.id, params.data.id))
    .returning();
  if (!product) {
    res.status(404).json({ error: "المنتج غير موجود." });
    return;
  }
  res.json(UpdateAdminProductResponse.parse(product));
});

router.delete("/admin/products/:id", async (req, res): Promise<void> => {
  const params = DeleteAdminProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [product] = await db
    .delete(productsTable)
    .where(eq(productsTable.id, params.data.id))
    .returning({ id: productsTable.id });
  if (!product) {
    res.status(404).json({ error: "المنتج غير موجود." });
    return;
  }
  res.sendStatus(204);
});

export default router;
