import assert from "node:assert/strict";
import test from "node:test";
import { clearOrdersAndRestock } from "../lib/clearOrders.ts";

function createStore(initialState) {
  const state = structuredClone(initialState);
  const metrics = {
    transactionCalls: 0,
    deleteCalls: 0,
    stockUpdates: [],
  };

  const transaction = async (work) => {
    metrics.transactionCalls += 1;
    const draft = structuredClone(state);
    const repository = {
      async lockAndReadOrders() {
        return structuredClone(draft.orders);
      },
      async restockVariant(productId, color, size, quantity) {
        const product = draft.products.find((candidate) => candidate.id === productId);
        if (!product) return false;
        const variant = product.variants.find(
          (candidate) => candidate.color === color && candidate.size === size,
        );
        // A variant deleted by the owner has nothing to restore; not an error.
        if (!variant) return true;
        variant.stock += quantity;
        product.stock = product.variants.reduce((sum, v) => sum + v.stock, 0);
        metrics.stockUpdates.push({ productId, color, size, quantity });
        return true;
      },
      async deleteAllOrders() {
        metrics.deleteCalls += 1;
        const deletedCount = draft.orders.length;
        draft.orders = [];
        return deletedCount;
      },
    };

    const result = await work(repository);
    state.products = draft.products;
    state.orders = draft.orders;
    return result;
  };

  return { state, metrics, transaction };
}

test("restocks eligible order variants once and reports actual changes", async () => {
  const store = createStore({
    products: [
      {
        id: "p1",
        stock: 10,
        variants: [
          { color: "أسود", size: "M", stock: 4 },
          { color: "أسود", size: "L", stock: 6 },
        ],
      },
      { id: "p2", stock: 20, variants: [{ color: "بيج", size: "S", stock: 20 }] },
    ],
    orders: [
      {
        status: "received",
        items: [
          { productId: "p1", color: "أسود", size: "M", quantity: 2 },
          { productId: "p2", color: "بيج", size: "S", quantity: 1 },
          { productId: "p1", color: "أسود", size: "M", quantity: 1 },
        ],
      },
      {
        status: "processing",
        items: [{ productId: "p1", color: "أسود", size: "L", quantity: 2 }],
      },
      {
        status: "delivered",
        items: [{ productId: "p2", color: "بيج", size: "S", quantity: 7 }],
      },
      {
        status: "cancelled",
        items: [{ productId: "p1", color: "أسود", size: "M", quantity: 11 }],
      },
    ],
  });

  const result = await clearOrdersAndRestock(store.transaction);

  assert.deepEqual(result, { deletedCount: 4, restockedUnits: 6 });
  assert.deepEqual(store.state.products[0].variants, [
    { color: "أسود", size: "M", stock: 7 },
    { color: "أسود", size: "L", stock: 8 },
  ]);
  assert.equal(store.state.products[0].stock, 15);
  assert.deepEqual(store.state.products[1].variants, [{ color: "بيج", size: "S", stock: 21 }]);
  assert.deepEqual(store.state.orders, []);
  assert.deepEqual(store.metrics.stockUpdates, [
    { productId: "p1", color: "أسود", size: "M", quantity: 3 },
    { productId: "p2", color: "بيج", size: "S", quantity: 1 },
    { productId: "p1", color: "أسود", size: "L", quantity: 2 },
  ]);
  assert.equal(store.metrics.transactionCalls, 1);
  assert.equal(store.metrics.deleteCalls, 1);
});
