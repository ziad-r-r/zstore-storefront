export type OrderCleanupItem = {
  productId: string;
  color: string;
  size: string;
  quantity: number;
};

export type OrderCleanupRecord = {
  status: string;
  items: OrderCleanupItem[];
};

export type OrderCleanupRepository = {
  lockAndReadOrders: () => Promise<OrderCleanupRecord[]>;
  restockVariant: (
    productId: string,
    color: string,
    size: string,
    quantity: number,
  ) => Promise<boolean>;
  deleteAllOrders: () => Promise<number>;
};

export type OrderCleanupTransaction = <T>(
  work: (repository: OrderCleanupRepository) => Promise<T>,
) => Promise<T>;

export async function clearOrdersAndRestock(
  transaction: OrderCleanupTransaction,
): Promise<{ deletedCount: number; restockedUnits: number }> {
  return transaction(async (repository) => {
    const orders = await repository.lockAndReadOrders();
    const quantities = new Map<string, OrderCleanupItem>();

    for (const order of orders) {
      if (order.status === "delivered" || order.status === "cancelled") continue;
      for (const item of order.items) {
        const key = `${item.productId}\u0001${item.color}\u0001${item.size}`;
        const existing = quantities.get(key);
        quantities.set(key, {
          ...item,
          quantity: (existing?.quantity ?? 0) + item.quantity,
        });
      }
    }

    let restockedUnits = 0;
    for (const item of quantities.values()) {
      const restocked = await repository.restockVariant(
        item.productId,
        item.color,
        item.size,
        item.quantity,
      );
      if (!restocked) {
        throw new Error(
          `Could not restore reserved stock for product ${item.productId}; orders were not deleted.`,
        );
      }
      restockedUnits += item.quantity;
    }

    const deletedCount = await repository.deleteAllOrders();
    return { deletedCount, restockedUnits };
  });
}
