export type Variant = { color: string; size: string; stock: number };

export type StockChange = { color: string; size: string; quantity: number };

export type StockResult =
  | { ok: true; variants: Variant[] }
  | { ok: false; color: string; size: string };

export function totalStock(variants: Variant[]): number {
  return variants.reduce((sum, variant) => sum + variant.stock, 0);
}

function applyChanges(variants: Variant[], changes: StockChange[], sign: 1 | -1): StockResult {
  const next = variants.map((variant) => ({ ...variant }));
  for (const change of changes) {
    const variant = next.find(
      (candidate) => candidate.color === change.color && candidate.size === change.size,
    );
    if (!variant) return { ok: false, color: change.color, size: change.size };
    const stock = variant.stock + sign * change.quantity;
    if (stock < 0) return { ok: false, color: change.color, size: change.size };
    variant.stock = stock;
  }
  return { ok: true, variants: next };
}

/** Takes stock out for an order. Fails without changing anything if any combination is short. */
export function reserveStock(variants: Variant[], changes: StockChange[]): StockResult {
  return applyChanges(variants, changes, -1);
}

/** Puts stock back, e.g. when an order is cancelled. */
export function releaseStock(variants: Variant[], changes: StockChange[]): StockResult {
  return applyChanges(variants, changes, 1);
}

export type NormalizedVariants =
  | { ok: true; variants: Variant[]; colors: string[]; sizes: string[] }
  | { ok: false; error: string };

/** Cleans admin input and derives the product's color and size lists from it. */
export function normalizeVariants(input: Variant[]): NormalizedVariants {
  const seen = new Set<string>();
  const variants: Variant[] = [];
  const colors: string[] = [];
  const sizes: string[] = [];

  for (const raw of input) {
    const color = raw.color.trim();
    const size = raw.size.trim();
    if (!color || !size) continue;
    const key = `${color}\u0001${size}`;
    if (seen.has(key)) {
      return { ok: false, error: `الاختيار ${color} / ${size} مكرر.` };
    }
    seen.add(key);
    if (!Number.isInteger(raw.stock) || raw.stock < 0) {
      return { ok: false, error: "الكمية يجب أن تكون رقمًا صحيحًا صفر أو أكثر." };
    }
    variants.push({ color, size, stock: raw.stock });
    if (!colors.includes(color)) colors.push(color);
    if (!sizes.includes(size)) sizes.push(size);
  }

  if (variants.length === 0) {
    return { ok: false, error: "أضيفي لونًا ومقاسًا واحدًا على الأقل." };
  }
  return { ok: true, variants, colors, sizes };
}
