import { jsonb, numeric, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { createInsertSchema } from "drizzle-zod";

export type StoredOrderLine = {
  productId: string;
  name: string;
  quantity: number;
  color: string;
  size: string;
  unitPrice: number;
  lineTotal: number;
  unitCommission?: number;
};

export const ordersTable = pgTable("zstore_orders", {
  id: text("id").primaryKey(),
  orderNo: text("order_no").notNull().unique(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  normalizedPhone: text("normalized_phone").notNull(),
  address: text("address").notNull(),
  items: jsonb("items").$type<StoredOrderLine[]>().notNull(),
  subtotal: numeric("subtotal", { precision: 10, scale: 2, mode: "number" }).notNull(),
  deliveryFee: numeric("delivery_fee", { precision: 10, scale: 2, mode: "number" }).notNull().default(80),
  total: numeric("total", { precision: 10, scale: 2, mode: "number" }).notNull(),
  status: text("status").notNull().default("received"),
  shippingLocation: text("shipping_location"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  createdAt: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
