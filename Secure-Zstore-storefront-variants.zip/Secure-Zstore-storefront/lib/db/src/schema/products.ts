import { integer, jsonb, numeric, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { createInsertSchema } from "drizzle-zod";

// Stock is tracked per color + size combination. `stock` on the product row is
// kept equal to the sum of these variants so summaries and low-stock alerts keep working.
export type StoredVariant = { color: string; size: string; stock: number };

export const productsTable = pgTable("zstore_products", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  priceSingle: numeric("price_single", { precision: 10, scale: 2, mode: "number" }).notNull(),
  priceBulk: numeric("price_bulk", { precision: 10, scale: 2, mode: "number" }).notNull(),
  commSingle: numeric("commission_single", { precision: 10, scale: 2, mode: "number" }).notNull().default(0),
  commBulk: numeric("commission_bulk", { precision: 10, scale: 2, mode: "number" }).notNull().default(0),
  colors: text("colors").array().notNull().default([]),
  sizes: text("sizes").array().notNull().default([]),
  image: text("image").notNull(),
  stock: integer("stock").notNull().default(0),
  variants: jsonb("variants").$type<StoredVariant[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertProductSchema = createInsertSchema(productsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
